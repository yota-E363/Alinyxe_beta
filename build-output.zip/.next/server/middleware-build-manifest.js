globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/78c46686f423b424.js",
    "static/chunks/806bdb8e4a6a9b95.js",
    "static/chunks/c284ff537f4f1dda.js",
    "static/chunks/383749250bd67cc9.js",
    "static/chunks/turbopack-518ea57c5e30d8c5.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];