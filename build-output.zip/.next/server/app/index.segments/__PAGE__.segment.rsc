1:"$Sreact.fragment"
2:I[2667,["/_next/static/chunks/60aee7a8ec9b892a.js","/_next/static/chunks/c5a7ea79d71d8330.js","/_next/static/chunks/61bc785dc6bd3109.js","/_next/static/chunks/291d50fb2fd478b5.js","/_next/static/chunks/dc0a6e13e5f6bfe0.js"],"default"]
3:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/d2be314c3ece3fbe.js"],"OutletBoundary"]
4:"$Sreact.suspense"
:HL["/_next/static/chunks/0a6ff56d9459c219.css","style"]
0:{"buildId":"0U7hjWMXd2iaT8X2lHkG2","rsc":["$","$1","c",{"children":[["$","$L2",null,{}],[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/0a6ff56d9459c219.css","precedence":"next"}],["$","script","script-0",{"src":"/_next/static/chunks/291d50fb2fd478b5.js","async":true}],["$","script","script-1",{"src":"/_next/static/chunks/dc0a6e13e5f6bfe0.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"loading":null,"isPartial":false}
5:null
