:HL["/_next/static/chunks/f4815bacf20f1ed6.css","style"]
:HL["/_next/static/chunks/0a6ff56d9459c219.css","style"]
0:{"buildId":"0U7hjWMXd2iaT8X2lHkG2","tree":{"name":"","paramType":null,"paramKey":"","hasRuntimePrefetch":false,"slots":{"children":{"name":"__PAGE__","paramType":null,"paramKey":"__PAGE__","hasRuntimePrefetch":false,"slots":null,"isRootLayout":false}},"isRootLayout":true},"staleTime":300}
