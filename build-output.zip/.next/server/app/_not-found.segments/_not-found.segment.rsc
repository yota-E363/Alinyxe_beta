1:"$Sreact.fragment"
2:I[39756,["/_next/static/chunks/72af59870003c52f.js","/_next/static/chunks/61bc785dc6bd3109.js","/_next/static/chunks/c5a7ea79d71d8330.js","/_next/static/chunks/d2be314c3ece3fbe.js"],"default"]
3:I[37457,["/_next/static/chunks/72af59870003c52f.js","/_next/static/chunks/61bc785dc6bd3109.js","/_next/static/chunks/c5a7ea79d71d8330.js","/_next/static/chunks/d2be314c3ece3fbe.js"],"default"]
0:{"buildId":"0U7hjWMXd2iaT8X2lHkG2","rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"loading":null,"isPartial":false}
