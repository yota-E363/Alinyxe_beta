1:"$Sreact.fragment"
2:I[97367,["/_next/static/chunks/72af59870003c52f.js","/_next/static/chunks/61bc785dc6bd3109.js","/_next/static/chunks/c5a7ea79d71d8330.js","/_next/static/chunks/d2be314c3ece3fbe.js"],"ViewportBoundary"]
3:I[97367,["/_next/static/chunks/72af59870003c52f.js","/_next/static/chunks/61bc785dc6bd3109.js","/_next/static/chunks/c5a7ea79d71d8330.js","/_next/static/chunks/d2be314c3ece3fbe.js"],"MetadataBoundary"]
4:"$Sreact.suspense"
0:{"buildId":"0U7hjWMXd2iaT8X2lHkG2","rsc":["$","$1","h",{"children":[["$","meta",null,{"name":"robots","content":"noindex"}],["$","$L2",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","div",null,{"hidden":true,"children":["$","$L3",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[]}]}]}],null]}],"loading":null,"isPartial":false}
