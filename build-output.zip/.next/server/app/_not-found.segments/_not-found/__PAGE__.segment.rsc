1:"$Sreact.fragment"
2:I[22016,["/_next/static/chunks/72af59870003c52f.js","/_next/static/chunks/61bc785dc6bd3109.js","/_next/static/chunks/c5a7ea79d71d8330.js","/_next/static/chunks/d2be314c3ece3fbe.js","/_next/static/chunks/2e25c7de70e0c09e.js"],""]
3:I[97367,["/_next/static/chunks/72af59870003c52f.js","/_next/static/chunks/61bc785dc6bd3109.js","/_next/static/chunks/c5a7ea79d71d8330.js","/_next/static/chunks/d2be314c3ece3fbe.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"buildId":"0U7hjWMXd2iaT8X2lHkG2","rsc":["$","$1","c",{"children":[["$","div",null,{"className":"min-h-screen flex flex-col items-center justify-center bg-background text-foreground","children":[["$","h1",null,{"className":"text-6xl font-bold glow-text mb-4","children":"404"}],["$","p",null,{"className":"text-xl mb-8","children":"Page non trouvée"}],["$","$L2",null,{"href":"/","className":"btn btn-primary","children":"Retour à l'accueil"}]]}],[["$","script","script-0",{"src":"/_next/static/chunks/2e25c7de70e0c09e.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"loading":null,"isPartial":false}
5:null
