module.exports=[68271,a=>{"use strict";a.s([])}];

//# sourceMappingURL=_next-internal_server_app_produits_%5Bslug%5D_page_actions_a42b86d7.js.map