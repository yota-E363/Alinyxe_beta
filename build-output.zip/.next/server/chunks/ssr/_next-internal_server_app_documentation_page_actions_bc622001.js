module.exports=[50254,a=>{"use strict";a.s([])}];

//# sourceMappingURL=_next-internal_server_app_documentation_page_actions_bc622001.js.map