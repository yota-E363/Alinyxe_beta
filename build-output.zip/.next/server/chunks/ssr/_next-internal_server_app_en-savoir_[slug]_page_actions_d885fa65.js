module.exports=[39617,a=>{"use strict";a.s([])}];

//# sourceMappingURL=_next-internal_server_app_en-savoir_%5Bslug%5D_page_actions_d885fa65.js.map